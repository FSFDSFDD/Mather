game:DefineFastFlag("VoiceChatStudioErrorToasts2", false)

return function()
	return game:GetFastFlag("VoiceChatStudioErrorToasts2")
end

game:DefineFastFlag("EnableVoiceChatPlayersListV2", false)

return function()
    return game:GetFastFlag("EnableVoiceChatPlayersListV2")
end

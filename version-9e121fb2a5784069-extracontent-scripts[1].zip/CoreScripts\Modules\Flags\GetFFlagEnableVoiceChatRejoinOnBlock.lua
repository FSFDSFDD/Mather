game:DefineFastFlag("EnableVoiceChatRejoinOnBlock", false)

return function()
    return game:GetFastFlag("EnableVoiceChatRejoinOnBlock")
end

game:DefineFastFlag("BubbleVoiceCheckInsertSize", false)

return function()
    return game:GetFastFlag("BubbleVoiceCheckInsertSize")
end

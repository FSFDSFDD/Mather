game:DefineFastFlag("OpenRootMenuInsteadOfSettings", false)

return function()
    return game:GetFastFlag("OpenRootMenuInsteadOfSettings")
end

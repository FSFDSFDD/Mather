return game:DefineFastFlag("EnableForkedChatAnalytics", false)

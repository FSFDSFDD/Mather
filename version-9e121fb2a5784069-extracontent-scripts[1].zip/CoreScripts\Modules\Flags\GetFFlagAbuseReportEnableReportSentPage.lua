game:DefineFastFlag("FFlagAbuseReportEnableReportSentPage", false)

return function()
	return game:GetFastFlag("FFlagAbuseReportEnableReportSentPage")
end

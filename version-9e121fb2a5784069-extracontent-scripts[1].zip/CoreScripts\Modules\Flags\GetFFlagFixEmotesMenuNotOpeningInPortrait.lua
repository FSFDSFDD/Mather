game:DefineFastFlag("FixEmotesMenuNotOpeningInPortrait", false)

return function()
	return game:GetFastFlag("FixEmotesMenuNotOpeningInPortrait")
end

game:DefineFastInt("EducationalPopupDisplayMaxCount", 0)
return function()
	return game:GetFastInt("EducationalPopupDisplayMaxCount")
end

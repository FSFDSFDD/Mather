game:DefineFastFlag("ModerationByProxyUserBanNotificationV4", false)

return function()
	return game:GetFastFlag("ModerationByProxyUserBanNotificationV4")
end

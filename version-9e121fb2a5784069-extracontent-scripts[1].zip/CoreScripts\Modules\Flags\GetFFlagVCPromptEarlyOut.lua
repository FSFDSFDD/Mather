game:DefineFastFlag("VCPromptEarlyOut", false)

return function()
    return game:GetFastFlag("VCPromptEarlyOut")
end

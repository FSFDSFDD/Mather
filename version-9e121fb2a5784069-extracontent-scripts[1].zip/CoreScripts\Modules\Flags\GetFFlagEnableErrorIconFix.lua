game:DefineFastFlag("EnableErrorIconFix", false)

return function()
	return game:GetFastFlag("EnableErrorIconFix")
end

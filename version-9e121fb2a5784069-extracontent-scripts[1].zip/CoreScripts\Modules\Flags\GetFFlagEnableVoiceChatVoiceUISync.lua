game:DefineFastFlag("EnableVoiceChatVoiceUISync", false)

return function()
    return game:GetFastFlag("EnableVoiceChatVoiceUISync")
end

game:DefineFastFlag("EnableDeferredBlockStatusChange", false)

return function()
    return game:GetFastFlag("EnableDeferredBlockStatusChange")
end

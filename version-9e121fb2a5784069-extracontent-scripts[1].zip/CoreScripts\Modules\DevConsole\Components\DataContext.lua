local CorePackages = game:GetService("CorePackages")
local Roact = require(CorePackages.Roact)

local DataContext = Roact.createContext()

return DataContext
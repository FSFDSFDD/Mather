game:DefineFastFlag("NewEmotesInGame2", false)

return function()
    return game:GetFastFlag("NewEmotesInGame2")
end

game:DefineFastFlag("BubbleVoiceIndicatorV2", false)

return function()
	return game:GetFastFlag("BubbleVoiceIndicatorV2")
end

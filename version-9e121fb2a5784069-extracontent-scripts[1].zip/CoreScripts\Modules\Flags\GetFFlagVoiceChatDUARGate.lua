game:DefineFastFlag("VoiceChatDUARGate", true)

return function()
    return game:GetFastFlag("VoiceChatDUARGate")
end

game:DefineFastFlag("EnableVoiceChatLocalMuteUI", false)

return function()
    return game:GetFastFlag("EnableVoiceChatLocalMuteUI")
end

return game:DefineFastFlag("MobilePlayerList2", false)

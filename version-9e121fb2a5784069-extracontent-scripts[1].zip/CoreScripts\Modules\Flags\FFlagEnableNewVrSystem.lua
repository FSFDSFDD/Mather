return game:DefineFastFlag("EnableNewVrSystem", false)

game:DefineFastFlag("SubscriptionFailureUX", false)

return function()
    return game:GetFastFlag("SubscriptionFailureUX")
end

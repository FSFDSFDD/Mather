game:DefineFastFlag("BubbleChatUserSpecificSettings", false)

return function()
	return game:GetFastFlag("BubbleChatUserSpecificSettings")
end

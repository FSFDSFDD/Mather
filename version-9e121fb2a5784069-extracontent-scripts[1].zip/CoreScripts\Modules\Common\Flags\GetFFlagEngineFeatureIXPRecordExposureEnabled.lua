return function()
    return game:GetEngineFeature("IXPRecordExposureEnabled")
end

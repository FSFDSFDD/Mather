game:DefineFastFlag("EnableVoiceChatNewMenu", false)

return function()
    return game:GetFastFlag("EnableVoiceChatNewMenu")
end

game:DefineFastFlag("ShowGitHashInGame", false)

return function()
    return game:GetFastFlag("ShowGitHashInGame")
end

game:DefineFastFlag("EnableVoiceChatDeviceChangeDebounce", false)

return function()
    return game:GetFastFlag("EnableVoiceChatDeviceChangeDebounce")
end

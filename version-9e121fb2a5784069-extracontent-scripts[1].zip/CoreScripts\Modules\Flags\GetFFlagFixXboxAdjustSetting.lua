game:DefineFastFlag("FixXboxAdjustSetting", false)

return function()
    return game:GetFastFlag("FixXboxAdjustSetting")
end

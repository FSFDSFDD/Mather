game:DefineFastFlag("EnableIXPInGame", false)

return function()
    return game:GetFastFlag("EnableIXPInGame")
end

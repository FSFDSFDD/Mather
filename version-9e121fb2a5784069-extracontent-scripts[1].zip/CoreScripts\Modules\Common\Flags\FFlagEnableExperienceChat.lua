return game:DefineFastFlag("EnableExperienceChat", false)

game:DefineFastFlag("OldMenuNewIcons", false)

return function()
    return game:GetFastFlag("OldMenuNewIcons")
end

game:DefineFastFlag("EnableVoiceDefaultChannel", false)

return function()
    return game:GetFastFlag("EnableVoiceDefaultChannel")
end

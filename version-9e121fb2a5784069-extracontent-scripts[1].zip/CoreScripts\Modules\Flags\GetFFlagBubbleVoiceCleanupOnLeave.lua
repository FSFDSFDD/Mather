game:DefineFastFlag("BubbleVoiceCleanupOnLeaveV2", false)

return function()
	return game:GetFastFlag("BubbleVoiceCleanupOnLeaveV2")
end

game:DefineFastFlag("EnableSessionCancelationOnBlock", false)

return function()
    return game:GetFastFlag("EnableSessionCancelationOnBlock")
end

local CorePackages = game:GetService("CorePackages")

local FFlagTempFixEmptyGridView = require(CorePackages.UIBloxFlags.FFlagTempFixEmptyGridView)
local FFlagTempFixGridViewLayoutWithSpawn = require(CorePackages.UIBloxFlags.FFlagTempFixGridViewLayoutWithSpawn)
local GetFFlagUIBloxFixDropdownMenuListPositionAndSize = require(CorePackages.UIBloxFlags.GetFFlagUIBloxFixDropdownMenuListPositionAndSize)
local GetFFlagUIBloxGenericButtonInputChangesInGame= require(CorePackages.UIBloxFlags.GetFFlagUIBloxGenericButtonInputChangesInGame)
local GetFFlagUIBloxEnableGamepadKeyCodeSupportForKeyLabel =
	require(CorePackages.UIBloxFlags.GetFFlagUIBloxEnableGamepadKeyCodeSupportForKeyLabel)
local GetFFlagUIBloxUseNewGenericTextLabelProps =
	require(CorePackages.UIBloxFlags.GetFFlagUIBloxUseNewGenericTextLabelProps)
local FFlagGenericButtonPassesMaxSizeToGenericTextLabel = require(CorePackages.UIBloxFlags.FFlagGenericButtonPassesMaxSizeToGenericTextLabel)
local FFlagImprovementsToGridView = require(CorePackages.UIBloxFlags.FFlagImprovementsToGridView)
local FFlagFixThumbnailTileInconsistency = require(CorePackages.UIBloxFlags.FFlagFixThumbnailTileInconsistency)

return {
	genericButtonPassesMaxSizeToGenericTextLabel = FFlagGenericButtonPassesMaxSizeToGenericTextLabel,
	improvementsToGridView = FFlagImprovementsToGridView,
	tempFixEmptyGridView = FFlagTempFixEmptyGridView,
	tempFixGridViewLayoutWithSpawn = FFlagTempFixGridViewLayoutWithSpawn,
	useUpdatedCheckbox = true,
	fixDropdownMenuListPositionAndSize = GetFFlagUIBloxFixDropdownMenuListPositionAndSize(),
	useNewGenericTextLabelProps = GetFFlagUIBloxUseNewGenericTextLabelProps(),
	useAnimatedXboxCursors = game:DefineFastFlag("GamepadAnimatedCursor", false),
	genericButtonInputChanges = GetFFlagUIBloxGenericButtonInputChangesInGame(),
	enableGamepadKeyCodeSupportForKeyLabel = GetFFlagUIBloxEnableGamepadKeyCodeSupportForKeyLabel(),
	enableAnimatedCursorForNonRoactGamepadComponent = game:DefineFastFlag("UIBloxEnableAnimatedCursorForNonRoactGamepad", false),
	fixTileThumbnailColorInconsistency = FFlagFixThumbnailTileInconsistency,
}

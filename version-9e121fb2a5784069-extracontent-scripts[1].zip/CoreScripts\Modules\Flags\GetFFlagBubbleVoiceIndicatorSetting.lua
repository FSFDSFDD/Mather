game:DefineFastFlag("BubbleVoiceIndicatorSetting", false)

return function()
	return game:GetFastFlag("BubbleVoiceIndicatorSetting")
end

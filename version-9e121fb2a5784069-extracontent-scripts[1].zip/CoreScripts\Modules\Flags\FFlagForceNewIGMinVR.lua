return game:DefineFastFlag("ForceNewIGMinVR", false)

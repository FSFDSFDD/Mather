game:DefineFastFlag("SendIsOptedInThroughUpsellParameter", false)

return function()
    return game:GetFastFlag("SendIsOptedInThroughUpsellParameter")
end

game:DefineFastFlag("PackInGameJoinDataEnabledClient", false)

return function()
	return game:GetFastFlag("PackInGameJoinDataEnabledClient")
end

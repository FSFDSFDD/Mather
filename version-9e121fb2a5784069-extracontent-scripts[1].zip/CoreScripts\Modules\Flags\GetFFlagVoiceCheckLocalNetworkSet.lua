game:DefineFastFlag("VoiceCheckLocalNetworkSet", false)

return function()
    return game:GetFastFlag("VoiceCheckLocalNetworkSet")
end

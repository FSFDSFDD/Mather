game:DefineFastFlag("NewSidebarInitalizationLogic", false)

return function()
    return game:GetFastFlag("NewSidebarInitalizationLogic")
end

game:DefineFastFlag("EnableVoiceChatManualReconnectV2", false)

return function()
    return game:GetFastFlag("EnableVoiceChatManualReconnectV2")
end


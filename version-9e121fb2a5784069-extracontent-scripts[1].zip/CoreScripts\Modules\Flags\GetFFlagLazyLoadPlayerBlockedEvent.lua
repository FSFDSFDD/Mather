game:DefineFastFlag("LazyLoadPlayerBlockedEvent", false)

return function()
    return game:GetFastFlag("LazyLoadPlayerBlockedEvent")
end

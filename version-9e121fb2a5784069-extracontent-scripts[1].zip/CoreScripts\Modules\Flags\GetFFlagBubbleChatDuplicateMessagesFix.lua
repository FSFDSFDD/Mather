game:DefineFastFlag("BubbleChatDuplicateMessagesFix", false)

return function()
	return game:GetFastFlag("BubbleChatDuplicateMessagesFix")
end

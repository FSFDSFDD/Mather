game:DefineFastFlag("FixDevConsoleInitialization", false)

return function()
	return game:GetFastFlag("FixDevConsoleInitialization")
end

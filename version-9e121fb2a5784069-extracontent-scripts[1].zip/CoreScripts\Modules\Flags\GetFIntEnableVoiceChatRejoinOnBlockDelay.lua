game:DefineFastInt("EnableVoiceChatRejoinOnBlockDelay", 10)
return function()
	return game:GetFastInt("EnableVoiceChatRejoinOnBlockDelay")
end

game:DefineFastFlag("EnableVoiceChatSpeakerIcons", false)

return function()
    return game:GetFastFlag("EnableVoiceChatSpeakerIcons")
end

return {
    PageAnimationDuration = 0.5,
	OpenMoreMenuAnimationDuration = 0.5,
	CloseMoreMenuAnimationDuration = 1,
}

return game:DefineFastFlag("LuaMacUpdateFullscreenKeyboardShortcut", false)

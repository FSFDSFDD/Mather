return game:DefineFastFlag("UseRoactGlobalConfigInCoreScripts", false)

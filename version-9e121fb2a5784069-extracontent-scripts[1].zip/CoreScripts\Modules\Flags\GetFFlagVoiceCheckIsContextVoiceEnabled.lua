game:DefineFastFlag("VoiceCheckIsContextVoiceEnabled", false)

return function()
    return game:GetFastFlag("VoiceCheckIsContextVoiceEnabled")
end

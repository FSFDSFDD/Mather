game:DefineFastFlag("EnableVoiceChatOptionsDualServiceOutputs", false)

return function()
    return game:GetFastFlag("EnableVoiceChatOptionsDualServiceOutputs")
end

game:DefineFastFlag("EnableVoiceChatMuteOnBlockV2", true)

return function()
    return game:GetFastFlag("EnableVoiceChatMuteOnBlockV2")
end

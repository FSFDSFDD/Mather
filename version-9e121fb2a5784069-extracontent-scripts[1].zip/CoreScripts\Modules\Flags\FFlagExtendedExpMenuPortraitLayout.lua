return game:DefineFastFlag("ExtendedExpMenuPortraitLayout", false)

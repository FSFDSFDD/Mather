game:DefineFastFlag("EnableVoiceMicPromptToastFix", false)

return function()
    return game:GetFastFlag("EnableVoiceMicPromptToastFix")
end


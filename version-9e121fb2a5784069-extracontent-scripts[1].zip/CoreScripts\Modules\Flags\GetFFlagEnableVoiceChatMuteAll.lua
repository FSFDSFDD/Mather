game:DefineFastFlag("EnableVoiceChatMuteAll", false)

return function()
    return game:GetFastFlag("EnableVoiceChatMuteAll")
end

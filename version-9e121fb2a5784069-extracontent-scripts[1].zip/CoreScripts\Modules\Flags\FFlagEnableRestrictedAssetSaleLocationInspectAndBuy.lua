return game:DefineFastFlag("EnableRestrictedAssetSaleLocationInspectAndBuy", false)
